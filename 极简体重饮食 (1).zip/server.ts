import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Set up server-side JSON and body parsing (generous size for uploaded images)
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Shared server-side Google GenAI initialization
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Helper to check if the user has provided a valid, non-placeholder API key
const isApiKeyValid = (): boolean => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return false;
  const k = key.trim();
  if (
    k === "" || 
    k === "MY_GEMINI_API_KEY" || 
    k === "YOUR_API_KEY" || 
    k.startsWith("YOUR_") || 
    k.startsWith("MY_")
  ) {
    return false;
  }
  return true;
};

// Local premium mathematical health recommendation algorithm
const calculateAdvisory = (profile: any, latestWeight: number) => {
  const height = profile?.height || 175;
  const weight = latestWeight || 70;
  const age = profile?.age || 28;
  const targetWeight = profile?.targetWeight || 70;
  const activityLevel = profile?.activityLevel || 'moderate';

  // Mifflin-St Jeor formula for BMR (Base Metabolic Rate)
  const bmr = 10 * weight + 6.25 * height - 5 * age + 5;

  const activityMultipliers = {
    sedentary: 1.25,
    light: 1.375,
    moderate: 1.55,
    active: 1.725
  };
  const multiplier = activityMultipliers[activityLevel as keyof typeof activityMultipliers] || 1.55;
  const maintenanceCalories = Math.round(bmr * multiplier);

  let targetCalories = maintenanceCalories;
  let coachMotto = "保持能量平衡状态，维持当前瘦体重与肌肉含量。";
  let guidelines: string[] = [
    "保持膳食多样化，保证微量元素摄入",
    "每公斤体重摄入 1.6-1.8g 蛋白质维持肌肉",
    "规律作息，保障每晚 7-8 小时高质量睡眠"
  ];

  const weightDiff = weight - targetWeight;

  if (weightDiff > 2) {
    targetCalories = Math.max(1300, Math.round(maintenanceCalories - 450));
    coachMotto = "保持每日温和热量赤字，多摄入饱腹感强的干净食材。";
    guidelines = [
      "制造 300-500 kcal 温和热量赤字，实现健康减脂",
      "餐前多饮水，每餐增加绿叶高纤蔬菜比例",
      "结合适度抗阻训练与有氧，保留宝贵的瘦体重"
    ];
  } else if (weightDiff < -2) {
    targetCalories = Math.round(maintenanceCalories + 300);
    coachMotto = "创造充足热量富盈，渐进提高训练负荷，促进干瘦体重增长。";
    guidelines = [
      "制造 200-300 kcal 干净盈余，全力促进肌肉合成",
      "在运动前后优先补充足量优质碳水与快速蛋白",
      "聚焦大重量复合动作，确保持续渐进超负荷"
    ];
  }

  let proteinFactor = 1.8;
  if (activityLevel === 'active') proteinFactor = 2.2;
  else if (activityLevel === 'moderate') proteinFactor = 2.0;
  else if (activityLevel === 'light') proteinFactor = 1.8;
  else proteinFactor = 1.6;

  const proteinTarget = Math.round(weight * proteinFactor);
  const fatTarget = Math.round((targetCalories * 0.25) / 9);
  const carbsTarget = Math.round((targetCalories - (proteinTarget * 4) - (fatTarget * 9)) / 4);

  return {
    targetCalories,
    proteinTarget,
    carbsTarget,
    fatTarget,
    guidelines,
    coachMotto
  };
};

// Local premium meal calorie and macro heuristic analyzer
const getLocalMealAnalysis = (mealType: string) => {
  const type = (mealType || 'breakfast').toLowerCase();
  
  if (type === 'breakfast') {
    return {
      mealName: "均衡营养早餐",
      calories: 350,
      carbs: 45,
      protein: 18,
      fat: 11,
      briefCoachAdvice: "优质碳水伴随适量卵磷脂与蛋白质，开启元气满满的活力一天。"
    };
  } else if (type === 'lunch') {
    return {
      mealName: "减脂高纤午餐",
      calories: 520,
      carbs: 60,
      protein: 35,
      fat: 15,
      briefCoachAdvice: "复合低GI碳水加饱腹瘦肉，是午后维持血糖稳定和体能的绝佳搭配。"
    };
  } else if (type === 'dinner') {
    return {
      mealName: "低碳高饱腹晚餐",
      calories: 420,
      carbs: 35,
      protein: 38,
      fat: 10,
      briefCoachAdvice: "控制晚餐碳水比例，充足的慢消化蛋白是睡眠中身体修复的基石。"
    };
  } else {
    return {
      mealName: "低脂补给温和加餐",
      calories: 180,
      carbs: 20,
      protein: 12,
      fat: 6,
      briefCoachAdvice: "少量加餐快速提升饱腹感，精密控卡，避免暴饮暴食。"
    };
  }
};

// API endpoint: Analyze food picture and estimate calories + macros
app.post("/api/analyze-meal", async (req, res) => {
  const { image, mealType, profile } = req.body;
  
  if (!image) {
    return res.status(400).json({ error: "No image base64 provided" });
  }

  // If no valid Gemini API key is configured or detected, fall back immediately to prevent unauthorized scopes exception
  if (!isApiKeyValid()) {
    console.log("Using localized meal analysis heuristics (Offline mode).");
    return res.json(getLocalMealAnalysis(mealType));
  }

  try {
    // Strip header from base64 if present (e.g. data:image/png;base64,xxxx)
    let base64Data = image;
    let mimeType = "image/jpeg";
    
    if (image.includes(";base64,")) {
      const parts = image.split(";base64,");
      const mimePart = parts[0];
      mimeType = mimePart.replace("data:", "");
      base64Data = parts[1];
    }

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: base64Data,
      },
    };

    const userContextPrompt = `
      You are an expert personal nutritionist representing a premium, ultra-lean meal journal app.
      Evaluate this meal photo uploaded by the user.
      User Profile Context: name: ${profile?.name}, age: ${profile?.age} year old male, height: ${profile?.height}cm, target weight: ${profile?.targetWeight}kg, activity level: ${profile?.activityLevel || 'moderate'}.
      
      Look at the image carefully and identify the food. Produce a JSON containing:
      1. mealName (Brief concise Chinese name of the food items identified)
      2. calories (Highly accurate estimation of total Calories in kcal, integer only)
      3. carbs (Estimated Carbohydrates in grams, integer)
      4. protein (Estimated Protein in grams, integer)
      5. fat (Estimated Fat in grams, integer)
      6. briefCoachAdvice (1 sentence of constructive, motivational diet advice in Chinese based on what you see in the food, keeping in mind his stats)
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [imagePart, userContextPrompt],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["mealName", "calories", "carbs", "protein", "fat", "briefCoachAdvice"],
          properties: {
            mealName: { type: Type.STRING, description: "Chinese name of the meal" },
            calories: { type: Type.INTEGER, description: "Total estimated calories in kcal" },
            carbs: { type: Type.INTEGER, description: "Carbohydrates in g" },
            protein: { type: Type.INTEGER, description: "Protein in g" },
            fat: { type: Type.INTEGER, description: "Fat in g" },
            briefCoachAdvice: { type: Type.STRING, description: "1 sentence motivational Chinese advice" },
          }
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from GenAI");
    }

    const result = JSON.parse(text);
    return res.json(result);

  } catch (error: any) {
    // If the call still fails (e.g. scopes, invalid key, or timeout), handle gracefully without spamming stderr
    const isScopeError = error?.message?.includes("scopes") || error?.message?.includes("PERMISSION_DENIED") || error?.status === 403;
    if (isScopeError) {
      console.warn("Gemini API access denied (insufficient key scopes). Utilizing adaptive offline analytics.");
    } else {
      console.error("Error analyzing meal image:", error?.message || error);
    }
    return res.json(getLocalMealAnalysis(mealType));
  }
});

// API endpoint: Get custom advisory ruleset based on user size
app.post("/api/daily-advice", async (req, res) => {
  const { profile, latestWeight } = req.body;

  // Use Mifflin-St Jeor offline model immediately if the API key is not valid to ensure a silent, pristine experience
  if (!isApiKeyValid()) {
    return res.json(calculateAdvisory(profile, latestWeight));
  }

  try {
    const prompt = `
      You are a world-class performance and physique coach. Provide an elegant daily health directive.
      User Profile: 
      - Name: ${profile.name}
      - Age: ${profile.age} (male)
      - Height: ${profile.height} cm
      - Current Weight: ${latestWeight} kg
      - Target Weight: ${profile.targetWeight} kg
      - Daily Activity Level: ${profile.activityLevel || 'moderate'}
      
      Suggest a highly tailored, non-cookie-cutter daily intake framework.
      Respond in Chinese in a clean, professional, concise JSON structure:
      1. targetCalories (Recommended daily calorie limit, integer)
      2. proteinTarget (Recommended daily protein in grams, integer)
      3. carbsTarget (Recommended daily carbs in grams, integer)
      4. fatTarget (Recommended daily fat in grams, integer)
      5. guidelines (An array of exactly 3 bullet-point expert level actionable, minimalist lifestyle suggestions, max 20 chars each)
      6. coachMotto (A powerful, inspiring 1-sentence performance motto in Chinese, keeping it aesthetic and focused)
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["targetCalories", "proteinTarget", "carbsTarget", "fatTarget", "guidelines", "coachMotto"],
          properties: {
            targetCalories: { type: Type.INTEGER },
            proteinTarget: { type: Type.INTEGER },
            carbsTarget: { type: Type.INTEGER },
            fatTarget: { type: Type.INTEGER },
            guidelines: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            coachMotto: { type: Type.STRING }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty advice response");
    
    return res.json(JSON.parse(text));
  } catch (error: any) {
    const isScopeError = error?.message?.includes("scopes") || error?.message?.includes("PERMISSION_DENIED") || error?.status === 403;
    if (isScopeError) {
      console.warn("Gemini API access denied (insufficient key scopes) for daily advisor. Applying calculated parameters.");
    } else {
      console.error("Error generating daily advice:", error?.message || error);
    }
    return res.json(calculateAdvisory(profile, latestWeight));
  }
});

// Vite Middleware orchestration for dev vs prod build serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static compiled assets in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening at http://localhost:${PORT}`);
  });
}

startServer();
