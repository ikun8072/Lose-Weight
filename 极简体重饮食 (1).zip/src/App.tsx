import { useState, useEffect, useMemo } from 'react';
import { WeightEntry, MealEntry, UserProfile, MealType } from './types';
import { defaultProfile, defaultMeals, defaultWeights } from './utils/mockData';
import StatsChart from './components/StatsChart';
import WeightForm from './components/WeightForm';
import MealForm from './components/MealForm';
import MealTimeline from './components/MealTimeline';
import WeightHistoryList from './components/WeightHistoryList';
import {
  Flame,
  TrendingDown,
  User,
  Scale,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  Info,
  Settings,
  Grid,
  CheckCircle,
  HelpCircle,
} from 'lucide-react';

export default function App() {
  // --- States ---
  const [profile, setProfile] = useState<UserProfile>(() => {
    const cached = localStorage.getItem('kg_profile');
    return cached ? JSON.parse(cached) : defaultProfile;
  });

  const [weights, setWeights] = useState<WeightEntry[]>(() => {
    const cached = localStorage.getItem('kg_weights');
    return cached ? JSON.parse(cached) : defaultWeights;
  });

  const [meals, setMeals] = useState<MealEntry[]>(() => {
    const cached = localStorage.getItem('kg_meals');
    return cached ? JSON.parse(cached) : defaultMeals;
  });

  const [activeTab, setActiveTab] = useState<'insights' | 'history'>('insights');
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);
  const [showQuickWeight, setShowQuickWeight] = useState<boolean>(false);
  const [showQuickMeal, setShowQuickMeal] = useState<boolean>(false);

  // Profile modal temporary states
  const [tempName, setTempName] = useState<string>(profile.name);
  const [tempHeight, setTempHeight] = useState<number>(profile.height);
  const [tempTarget, setTempTarget] = useState<number>(profile.targetWeight);
  const [tempAge, setTempAge] = useState<number>(profile.age);
  const [tempActivityLevel, setTempActivityLevel] = useState<'sedentary' | 'light' | 'moderate' | 'active'>(profile.activityLevel || 'moderate');
  const [tempApiServerUrl, setTempApiServerUrl] = useState<string>(profile.apiServerUrl || '');

  // Coach advice and layout metrics
  const [coachAdvice, setCoachAdvice] = useState<{
    targetCalories: number;
    proteinTarget: number;
    carbsTarget: number;
    fatTarget: number;
    guidelines: string[];
    coachMotto: string;
  } | null>(() => {
    const cached = localStorage.getItem('kg_coach_advice');
    return cached ? JSON.parse(cached) : null;
  });
  const [isFetchingAdvice, setIsFetchingAdvice] = useState<boolean>(false);

  // --- Effects for Storage Persistence ---
  useEffect(() => {
    localStorage.setItem('kg_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('kg_weights', JSON.stringify(weights));
  }, [weights]);

  useEffect(() => {
    localStorage.setItem('kg_meals', JSON.stringify(meals));
  }, [meals]);

  // Method to fetch daily coach recommendations using Google Gemini
  const fetchAdvice = async (currentProfile: UserProfile, weightVal: number) => {
    if (isFetchingAdvice) return;
    setIsFetchingAdvice(true);
    try {
      const apiBase = (currentProfile.apiServerUrl || '').trim().replace(/\/+$/, '');
      const response = await fetch(`${apiBase}/api/daily-advice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile: currentProfile, latestWeight: weightVal })
      });
      if (response.ok) {
        const result = await response.json();
        setCoachAdvice(result);
        localStorage.setItem('kg_coach_advice', JSON.stringify(result));
      }
    } catch (err) {
      console.error("Failed to fetch advice", err);
    } finally {
      setIsFetchingAdvice(false);
    }
  };

  // --- Derived Indicators ---
  const sortedWeights = useMemo(() => {
    return [...weights].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [weights]);

  const latestWeight = useMemo(() => {
    if (sortedWeights.length === 0) return 0;
    return sortedWeights[sortedWeights.length - 1].weight;
  }, [sortedWeights]);

  // --- Operations ---
  const handleAddWeight = (val: number, note?: string) => {
    const todayStr = new Date().toISOString().split('T')[0];
    
    // Check if entry for today already exists; if so, replace it, otherwise append.
    // This maintains "last record per day" simplicity!
    const existingIndex = weights.findIndex(w => w.date === todayStr);
    
    if (existingIndex >= 0) {
      const updated = [...weights];
      updated[existingIndex] = {
        ...updated[existingIndex],
        weight: val,
        note: note || updated[existingIndex].note
      };
      setWeights(updated);
    } else {
      const newEntry: WeightEntry = {
        id: `w-${Date.now()}`,
        date: todayStr,
        weight: val,
        note
      };
      setWeights(prev => [...prev, newEntry]);
    }
    setShowQuickWeight(false);
  };

  const handleDeleteWeight = (id: string) => {
    setWeights(prev => prev.filter(w => w.id !== id));
  };

  const handleAddMeal = (
    type: MealType,
    image: string,
    note?: string,
    nutrition?: { calories: number; carbs: number; protein: number; fat: number; mealName: string }
  ) => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0].substring(0, 5); // HH:MM

    const newEntry: MealEntry = {
      id: `m-${Date.now()}`,
      date: todayStr,
      time: timeStr,
      type,
      image,
      note,
      calories: nutrition?.calories,
      carbs: nutrition?.carbs,
      protein: nutrition?.protein,
      fat: nutrition?.fat
    };

    setMeals(prev => [newEntry, ...prev]);
    setShowQuickMeal(false);
  };

  const handleDeleteMeal = (id: string) => {
    setMeals(prev => prev.filter(m => m.id !== id));
  };

  const handleSaveProfile = () => {
    const updatedProfile: UserProfile = {
      name: tempName,
      age: tempAge,
      height: tempHeight,
      targetWeight: tempTarget,
      activityLevel: tempActivityLevel,
      apiServerUrl: tempApiServerUrl
    };
    setProfile(updatedProfile);
    
    if (latestWeight > 0) {
      fetchAdvice(updatedProfile, latestWeight);
    }
    
    setShowProfileModal(false);
  };

  // Re-fetch custom fitness coach suggestions when weight or profile specs transition
  useEffect(() => {
    if (profile && latestWeight > 0) {
      fetchAdvice(profile, latestWeight);
    }
  }, [profile.height, profile.targetWeight, profile.activityLevel, latestWeight]);

  const heightInMeters = profile.height / 100;
  const currentBmi = heightInMeters > 0 ? (latestWeight / (heightInMeters * heightInMeters)) : 0;

  // Safe Goal Progress calculations
  const goalStats = useMemo(() => {
    if (weights.length === 0) {
      return {
        hasWeights: false,
        initialWeight: 0,
        lostWeight: 0,
        progressPercent: 0,
      };
    }
    const initial = weights[0].weight;
    const latest = latestWeight;
    const lost = Math.max(0, initial - latest);
    const targetDiff = initial - profile.targetWeight;
    const percent = targetDiff > 0 ? Math.min(100, Math.max(0, (lost / targetDiff) * 100)) : 0;
    
    return {
      hasWeights: true,
      initialWeight: initial,
      lostWeight: lost,
      progressPercent: percent,
    };
  }, [weights, latestWeight, profile.targetWeight]);

  // Meal stats helper
  const todayMealsCount = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    return meals.filter(m => m.date === todayStr).length;
  }, [meals]);

  return (
    <div id="root-viewport" className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans transition-all duration-150">
      
      {/* Glow Ambient header backdrop */}
      <div className="absolute top-0 inset-x-0 h-80 bg-gradient-to-b from-emerald-500/5 to-transparent blur-[120px] pointer-events-none" />

      {/* Main Container */}
      <div className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 flex flex-col gap-6 relative z-10">
        
        {/* Upper Navigation / Meta Info */}
        <header className="flex items-center justify-between border-b border-neutral-900 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/10">
              <Scale size={20} className="text-neutral-950 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 tracking-wider uppercase font-semibold">PERSONAL INDEX</span>
                <span className="inline-block px-1.5 py-0.2 text-[8px] bg-neutral-900 rounded border border-neutral-800 text-neutral-450 font-mono">V1.0</span>
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">极简体重饮食</h1>
            </div>
          </div>

          {/* Quick Profile config trigger */}
          <button
            onClick={() => {
              setTempName(profile.name);
              setTempHeight(profile.height);
              setTempTarget(profile.targetWeight);
              setTempAge(profile.age);
              setTempActivityLevel(profile.activityLevel || 'moderate');
              setTempApiServerUrl(profile.apiServerUrl || '');
              setShowProfileModal(true);
            }}
            id="btn-edit-profile"
            className="flex items-center gap-2 bg-neutral-900 hover:bg-neutral-850 hover:text-white border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-neutral-300 transition-all cursor-pointer active:scale-95"
          >
            <User size={14} className="text-neutral-400" />
            <span className="font-medium hidden sm:inline">{profile.name} (178cm/目标{profile.targetWeight}kg)</span>
            <span className="font-medium sm:hidden">{profile.name}</span>
            <Settings size={12} className="text-neutral-500" />
          </button>
        </header>

        {/* Dashboard Grid & Quick Actions Bar */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Quick Floating Buttons (Sticky trigger on mobile for utmost agility of speed) */}
          <div className="md:col-span-3 flex items-center justify-between gap-4 bg-neutral-900/60 backdrop-blur-md border border-neutral-850 p-4 rounded-2xl">
            <div className="flex items-center gap-2.5">
              <Flame size={18} className="text-amber-400 animate-pulse" />
              <div className="text-left">
                <p className="text-xs text-neutral-400 leading-none">今日进度打卡</p>
                <p className="text-[10px] text-neutral-500 mt-1 font-mono">
                  影像: {todayMealsCount} 餐 | 体重: {weights.some(w => w.date === new Date().toISOString().split('T')[0]) ? '✅ 已录入' : '⏳ 待记录'}
                </p>
              </div>
            </div>

            {/* Suspended Core Button Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowQuickMeal(false);
                  setShowQuickWeight(!showQuickWeight);
                }}
                id="floating-btn-weight"
                className="bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-500/10 active:scale-95 transition-all text-xs flex items-center gap-1.5"
              >
                <Plus size={15} />
                <span>记体重</span>
              </button>
              
              <button
                onClick={() => {
                  setShowQuickWeight(false);
                  setShowQuickMeal(!showQuickMeal);
                }}
                id="floating-btn-meal"
                className="bg-sky-500 hover:bg-sky-400 text-neutral-950 font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-sky-500/10 active:scale-95 transition-all text-xs flex items-center gap-1.5"
              >
                <Plus size={15} />
                <span>拍美食</span>
              </button>
            </div>
          </div>

          {/* Collapsible Action Drawer: Weight */}
          {showQuickWeight && (
            <div id="collapsible-action-weight" className="md:col-span-3 animate-in fade-in slide-in-from-top-4 duration-200">
              <WeightForm onAddWeight={handleAddWeight} latestWeight={latestWeight} />
            </div>
          )}

          {/* Collapsible Action Drawer: Meal */}
          {showQuickMeal && (
            <div id="collapsible-action-meal" className="md:col-span-3 animate-in fade-in slide-in-from-top-4 duration-200">
              <MealForm onAddMeal={handleAddMeal} profile={profile} />
            </div>
          )}

          {/* Dynamic Big Graph Row */}
          <div className="md:col-span-3">
            <StatsChart entries={weights} profile={profile} />
          </div>

          {/* Custom Tabs Navigation for Insights vs History Waterfall */}
          <div className="md:col-span-3 flex justify-center mt-2">
            <div className="flex bg-neutral-950/80 p-1 rounded-xl border border-neutral-850 w-full max-w-sm justify-between">
              <button
                onClick={() => setActiveTab('insights')}
                id="main-tab-insights"
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all text-center flex items-center justify-center gap-1.5 ${
                  activeTab === 'insights'
                    ? 'bg-neutral-850 text-emerald-400 border border-neutral-800'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Grid size={13} />
                核心看版
              </button>
              
              <button
                onClick={() => setActiveTab('history')}
                id="main-tab-history"
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all text-center flex items-center justify-center gap-1.5 ${
                  activeTab === 'history'
                    ? 'bg-neutral-850 text-sky-400 border border-neutral-800'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Calendar size={13} />
                全历史流
              </button>
            </div>
          </div>

          {/* Active section renders based on selection */}
          {activeTab === 'insights' ? (
            <>
              {/* Left Column: Log and widgets */}
              <div className="md:col-span-1 space-y-6">
                
                {/* Micro Metric Widgets: Target goals */}
                <div id="goal-widget" className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4 text-left">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-neutral-400 uppercase">目标管理</span>
                    <Sparkles size={14} className="text-amber-400" />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1 font-semibold text-neutral-300">
                      <span>已减去: {goalStats.lostWeight.toFixed(1)} kg</span>
                      <span>目标: {profile.targetWeight.toFixed(1)} kg</span>
                    </div>

                    {/* Simple static progress gauge */}
                    <div className="h-2 bg-neutral-950 rounded-full overflow-hidden border border-neutral-850">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full transition-all duration-300"
                        style={{
                          width: `${goalStats.progressPercent}%`
                        }}
                      />
                    </div>
                  </div>
                  <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-850/50 flex gap-2">
                    <Info size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                    <p className="text-[10px] text-neutral-400 leading-relaxed">
                      基于您的身高 <span className="font-semibold text-neutral-200">{profile.height} cm</span>，健康BMI区间对应的合理体重为 58.6 - 76.0 kg。
                    </p>
                  </div>
                </div>

                {/* Left Mini Logger list */}
                <WeightHistoryList entries={weights} profile={profile} onDeleteWeight={handleDeleteWeight} />
              </div>

              {/* Right Column: Daily photo entries on dashboard && AI Fitness Advisor */}
              <div className="md:col-span-2 space-y-6">
                
                {/* AI Physical Diet Coach Advisory Card */}
                {isFetchingAdvice ? (
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-4 animate-pulse text-left relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 rounded-full blur-2xl" />
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-neutral-800" />
                      <div className="space-y-1.5 flex-1">
                        <div className="h-4 bg-neutral-800 rounded w-1/4" />
                        <div className="h-2.5 bg-neutral-800 rounded w-1/2" />
                      </div>
                    </div>
                    <div className="h-24 bg-neutral-950/60 rounded-2xl border border-neutral-850/30" />
                  </div>
                ) : coachAdvice ? (
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-xl text-left relative overflow-hidden group">
                    {/* Futuristic accent layer */}
                    <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/[0.03] rounded-full blur-[48px] pointer-events-none" />
                    
                    {/* Heading header */}
                    <div className="flex items-center justify-between mb-4 pb-3 border-b border-neutral-850">
                      <div className="flex items-center gap-2.5 text-neutral-200">
                        <div className="w-8 h-8 rounded-xl bg-sky-500/15 border border-sky-450/20 flex items-center justify-center text-sky-400">
                          <Sparkles size={16} />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-white tracking-tight">AI 私人身材 Coach 方案</h3>
                          <p className="text-[10px] text-neutral-400 font-mono">根据最新身材系数与每日运动量即时拟制</p>
                        </div>
                      </div>
                      <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-neutral-950 border border-neutral-800 text-sky-400">
                        {profile.activityLevel === 'sedentary' && '久坐少动'}
                        {profile.activityLevel === 'light' && '轻度自律'}
                        {profile.activityLevel === 'moderate' && '中度频繁'}
                        {profile.activityLevel === 'active' && '高强度训练'}
                      </span>
                    </div>

                    {/* Calorie & Macro Target Grid */}
                    <div className="grid grid-cols-4 gap-2 bg-neutral-950 p-4 rounded-2xl border border-neutral-850/60 mb-4 shadow-inner text-center">
                      <div>
                        <div className="text-[10px] text-neutral-500 font-medium">每日摄入上限</div>
                        <div className="text-sm sm:text-base font-extrabold text-sky-400 mt-1">{coachAdvice.targetCalories} kcal</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-neutral-500 font-medium font-sans">蛋白质配额</div>
                        <div className="text-xs sm:text-sm font-bold text-emerald-450 mt-1">{coachAdvice.proteinTarget}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-neutral-500 font-medium font-sans">碳水参考</div>
                        <div className="text-xs sm:text-sm font-bold text-amber-400 mt-1">{coachAdvice.carbsTarget}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-neutral-500 font-medium font-sans">优质脂肪</div>
                        <div className="text-xs sm:text-sm font-bold text-rose-450 mt-1">{coachAdvice.fatTarget}g</div>
                      </div>
                    </div>

                    {/* Bullet recommendation list */}
                    <div className="space-y-2.5">
                      <div className="text-[10px] uppercase font-mono text-neutral-500 font-bold tracking-wider">今日 Coach 行为控制指南</div>
                      <div className="grid grid-cols-1 gap-2">
                        {coachAdvice.guidelines.map((line, idx) => (
                          <div key={idx} className="flex gap-2.5 items-start text-xs text-neutral-300 bg-neutral-950/45 px-3 py-2.5 border border-neutral-850/40 rounded-xl">
                            <span className="text-emerald-400 shrink-0 mt-0.5">✔</span>
                            <span className="leading-relaxed font-sans">{line}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Motto */}
                    <div className="border-t border-neutral-850/30 mt-4 pt-3 text-center sm:text-left flex items-center justify-between">
                      <p className="text-[11px] text-neutral-400 select-none italic font-sans flex items-center gap-1.5 leading-relaxed">
                        <Flame size={12} className="text-amber-400" />
                        "{coachAdvice.coachMotto}"
                      </p>
                    </div>
                  </div>
                ) : null}

                <MealTimeline meals={meals} weights={weights} onDeleteMeal={handleDeleteMeal} />
              </div>
            </>
          ) : (
            // Full screen view of log outputs for simplified data lookup
            <div className="md:col-span-3 space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                  <WeightHistoryList entries={weights} profile={profile} onDeleteWeight={handleDeleteWeight} />
                </div>
                <div className="lg:col-span-2">
                  <MealTimeline meals={meals} weights={weights} onDeleteMeal={handleDeleteMeal} />
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer info branding */}
        <footer className="border-t border-neutral-900 pt-6 mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500 font-mono">
          <p>© 2026 极简个人体重与饮食记录系统</p>
          <div className="flex gap-4">
            <span>自适应智能减阻</span>
            <span>•</span>
            <span>100% 隐私化纯净体感</span>
          </div>
        </footer>

      </div>

      {/* Profile Modification dialog popup */}
      {showProfileModal && (
        <div id="profile-modal-backdrop" className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-sm w-full p-6 text-left shadow-2xl space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">配置身材档案</h3>
              <p className="text-xs text-neutral-450 mt-0.5">这些档案参数仅储存在您本地浏览器中</p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="space-y-1">
                <label htmlFor="pf-name" className="text-[10px] uppercase font-mono text-neutral-500">姓名称号</label>
                <input
                  id="pf-name"
                  type="text"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label htmlFor="pf-height" className="text-[10px] uppercase font-mono text-neutral-500">身高 (cm)</label>
                  <input
                    id="pf-height"
                    type="number"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                    value={tempHeight}
                    onChange={(e) => setTempHeight(parseInt(e.target.value) || 178)}
                  />
                </div>
                
                <div className="space-y-1">
                  <label htmlFor="pf-age" className="text-[10px] uppercase font-mono text-neutral-500">年龄</label>
                  <input
                    id="pf-age"
                    type="number"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                    value={tempAge}
                    onChange={(e) => setTempAge(parseInt(e.target.value) || 22)}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="pf-target" className="text-[10px] uppercase font-mono text-neutral-500">目标体重 (kg)</label>
                <input
                  id="pf-target"
                  type="number"
                  step="0.1"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  value={tempTarget}
                  onChange={(e) => setTempTarget(parseFloat(e.target.value) || 70)}
                />
              </div>

              <div className="space-y-1 font-sans">
                <label htmlFor="pf-activity" className="text-[10px] uppercase font-mono text-neutral-500">每日运动量 / 活动级别</label>
                <select
                  id="pf-activity"
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-sans cursor-pointer text-xs"
                  value={tempActivityLevel}
                  onChange={(e) => setTempActivityLevel(e.target.value as any)}
                >
                  <option value="sedentary">久坐少动 (全天静坐、少运动)</option>
                  <option value="light">轻度自律 (偶尔散步、微量拉伸)</option>
                  <option value="moderate">中度频繁 (每周规律运动3-4次)</option>
                  <option value="active">高强度训练 (重度健身、马拉松/重训)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label htmlFor="pf-api-url" className="text-[10px] uppercase font-mono text-neutral-500">
                  云端 API 服务器链接 (手机 App 选填)
                </label>
                <input
                  id="pf-api-url"
                  type="url"
                  placeholder="https://your-app-url.run.app"
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500 font-sans text-xs"
                  value={tempApiServerUrl}
                  onChange={(e) => setTempApiServerUrl(e.target.value)}
                />
                <p className="text-[9px] text-neutral-500 font-sans leading-normal">
                  若打包为手机 APK，填入您部署在云端的 Cloud Run 或静态 Web URL，即可在手机中畅享 AI 极速配餐识别。
                </p>
              </div>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowProfileModal(false)}
                className="flex-1 bg-neutral-950 hover:bg-neutral-850 text-neutral-400 py-2.5 rounded-xl border border-neutral-800 text-xs font-semibold"
              >
                取消
              </button>
              <button
                onClick={handleSaveProfile}
                className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 py-2.5 rounded-xl text-xs font-semibold"
              >
                保存配置
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
