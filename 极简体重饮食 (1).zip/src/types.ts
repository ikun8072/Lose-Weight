export interface WeightEntry {
  id: string;
  date: string; // YYYY-MM-DD
  weight: number; // in kg
  note?: string;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface MealEntry {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  type: MealType;
  image: string; // base64 or blob URL
  note?: string;
  calories?: number; // estimated kcal
  carbs?: number; // g
  protein?: number; // g
  fat?: number; // g
}

export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active';

export interface UserProfile {
  height: number; // in cm, e.g., 178
  targetWeight: number; // in kg
  name: string;
  age: number;
  activityLevel: ActivityLevel;
  apiServerUrl?: string; // remote Express backend server URL for mobile APK clients
}
