import React, { useState } from 'react';
import { WeightEntry } from '../types';

interface WeightFormProps {
  onAddWeight: (weight: number, note?: string) => void;
  latestWeight: number;
}

export default function WeightForm({ onAddWeight, latestWeight }: WeightFormProps) {
  // Use the latest weight as a starting point. If zero, default to a standard 22yo male avg e.g. 75kg
  const defaultWeight = latestWeight > 0 ? latestWeight : 75.0;
  const [weight, setWeight] = useState<number>(defaultWeight);
  const [note, setNote] = useState<string>('');
  
  // Custom quick selectors for small daily increments based on latest recorded weight
  const increments = [-1.0, -0.5, -0.2, -0.1, 0, 0.1, 0.2, 0.5, 1.0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (weight <= 30 || weight >= 300) return; // simple sanity guard
    onAddWeight(parseFloat(weight.toFixed(1)), note.trim() || undefined);
    setNote('');
  };

  const handleAdjustWeight = (amt: number) => {
    setWeight(prev => Math.round((prev + amt) * 10) / 10);
  };

  return (
    <div id="weight-picker-form" className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-[48px] pointer-events-none" />
      
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">记体重</h2>
          <p className="text-xs text-neutral-400 mt-0.5">每日空腹测定，极速捕捉微澜</p>
        </div>
        <span className="text-[10px] font-mono bg-neutral-950 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
          3-SEC LOG
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Huge Interactive Display Control */}
        <div className="bg-neutral-950 border border-neutral-850 rounded-xl p-5 flex flex-col items-center justify-center relative">
          <span className="text-[10px] uppercase font-mono text-neutral-500 mb-1">当前设定</span>
          
          <div className="flex items-center gap-6">
            <button
              type="button"
              id="weight-minus-button"
              onClick={() => handleAdjustWeight(-0.1)}
              className="w-10 h-10 rounded-full border border-neutral-800 bg-neutral-900 text-neutral-300 hover:text-white hover:border-neutral-600 active:scale-95 transition-all text-xl flex items-center justify-center font-bold"
            >
              -
            </button>
            
            <div className="text-center">
              <input
                type="number"
                id="weight-numeric-input"
                step="0.1"
                min="30"
                max="250"
                className="bg-transparent text-center text-4xl font-extrabold text-white font-sans focus:outline-none w-36 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                value={weight}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (!isNaN(val)) setWeight(val);
                }}
              />
              <span className="text-xs text-neutral-500 block mt-0.5">kg</span>
            </div>

            <button
              type="button"
              id="weight-plus-button"
              onClick={() => handleAdjustWeight(0.1)}
              className="w-10 h-10 rounded-full border border-neutral-800 bg-neutral-900 text-neutral-300 hover:text-white hover:border-neutral-600 active:scale-95 transition-all text-xl flex items-center justify-center font-bold"
            >
              +
            </button>
          </div>

          {/* Quick Slider Adjustment */}
          <div className="w-full mt-4 px-2">
            <input
              type="range"
              id="weight-slider"
              min={Math.max(30, defaultWeight - 5)}
              max={defaultWeight + 5}
              step="0.1"
              value={weight}
              onChange={(e) => setWeight(parseFloat(parseFloat(e.target.value).toFixed(1)))}
              className="w-full h-1 bg-neutral-850 rounded-lg appearance-none cursor-pointer accent-emerald-500 focus:outline-none"
            />
            <div className="flex justify-between text-[9px] font-mono text-neutral-550 mt-1">
              <span>{(defaultWeight - 5).toFixed(1)} kg</span>
              <span className="text-neutral-400 font-semibold">最新基准: {defaultWeight.toFixed(1)} kg</span>
              <span>{(defaultWeight + 5).toFixed(1)} kg</span>
            </div>
          </div>
        </div>

        {/* Dynamic Quick Adjust Chips */}
        <div>
          <span className="text-[10px] uppercase font-mono text-neutral-500 block mb-2">微调偏差</span>
          <div className="flex flex-wrap gap-1.5">
            {increments.map((inc) => {
              if (inc === 0) return null;
              const isNeg = inc < 0;
              return (
                <button
                  key={inc}
                  type="button"
                  id={`adjust-chip-${inc}`}
                  onClick={() => handleAdjustWeight(inc)}
                  className={`text-[11px] font-mono px-2 py-1 rounded border min-w-[42px] transition-all hover:scale-[1.03] active:scale-95 ${
                    isNeg
                      ? 'border-emerald-900/40 bg-emerald-950/15 text-emerald-400 hover:bg-emerald-950/30'
                      : 'border-rose-900/40 bg-rose-950/15 text-rose-400 hover:bg-rose-950/30'
                  }`}
                >
                  {isNeg ? '' : '+'}{inc.toFixed(1)}
                </button>
              );
            })}
          </div>
        </div>

        {/* Note (Optional) */}
        <div className="space-y-1.5">
          <label htmlFor="weight-note-input" className="text-[10px] uppercase font-mono text-neutral-500">备注 (可选)</label>
          <input
            id="weight-note-input"
            type="text"
            className="w-full bg-neutral-950 border border-neutral-850 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-all"
            placeholder="例: 早晨空腹、运动后、高盐排毒期"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        {/* Submission button */}
        <button
          type="submit"
          id="btn-submit-weight"
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-semibold py-3 px-4 rounded-xl shadow-lg shadow-emerald-500/10 active:scale-[0.98] transition-all text-xs tracking-wider uppercase font-mono flex items-center justify-center gap-1"
        >
          确认并保存记录
        </button>
      </form>
    </div>
  );
}
