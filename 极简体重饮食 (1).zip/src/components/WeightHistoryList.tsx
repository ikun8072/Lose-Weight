import React, { useMemo } from 'react';
import { WeightEntry, UserProfile } from '../types';
import { Trash2, TrendingDown, TrendingUp, Minus, Calendar, Award, User, Tag } from 'lucide-react';

interface WeightHistoryListProps {
  entries: WeightEntry[];
  profile: UserProfile;
  onDeleteWeight: (id: string) => void;
}

export default function WeightHistoryList({ entries, profile, onDeleteWeight }: WeightHistoryListProps) {
  
  // Sort chronological descending
  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [entries]);

  // Map elements to calculate relative delta compared to previous weight (chronologically increasing)
  const entriesWithDeltas = useMemo(() => {
    const sortedAsc = [...entries].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const deltas: Record<string, number> = {};

    sortedAsc.forEach((entry, idx) => {
      if (idx === 0) {
        deltas[entry.id] = 0; // first entry has no prior reference
      } else {
        const prev = sortedAsc[idx - 1];
        deltas[entry.id] = Math.round((entry.weight - prev.weight) * 10) / 10;
      }
    });

    return sortedEntries.map(entry => ({
      ...entry,
      delta: deltas[entry.id] ?? 0
    }));
  }, [entries, sortedEntries]);

  // Helper BMI calculator with premium color designs
  const getBmiDetails = (weight: number) => {
    const heightInMeters = profile.height / 100;
    const bmi = heightInMeters > 0 ? Math.round((weight / (heightInMeters * heightInMeters)) * 10) / 10 : 0;
    
    let text = '标准正常';
    let bg = 'bg-emerald-500/10 text-emerald-450 border-emerald-500/20';
    if (bmi < 18.5) {
      text = '体重偏轻';
      bg = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    } else if (bmi >= 24 && bmi < 28) {
      text = '超重微胖';
      bg = 'bg-orange-500/10 text-orange-400 border-orange-500/20';
    } else if (bmi >= 28) {
      text = '轻度肥胖';
      bg = 'bg-rose-500/10 text-rose-450 border-rose-500/20';
    }
    return { bmi, text, bg };
  };

  return (
    <div id="weights-history-card" className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-xl space-y-6">
      <div className="flex items-center justify-between border-b border-neutral-800/60 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            体重管理日志
          </h2>
          <p className="text-xs text-neutral-400">追踪身体脂肪比例与每日去脂体质量轨迹</p>
        </div>
        <span className="text-xs bg-neutral-950 px-3 py-1 rounded-full border border-neutral-800 text-neutral-400 font-medium">
          已记录 {entries.length} 次
        </span>
      </div>

      {entriesWithDeltas.length > 0 ? (
        <div className="space-y-4 max-h-[32rem] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-neutral-800">
          {entriesWithDeltas.map((entry) => {
            const { bmi, text: bmiText, bg: bmiBadgeClass } = getBmiDetails(entry.weight);
            const hasChange = entry.delta !== 0;
            const isGain = entry.delta > 0;

            return (
              <div
                key={entry.id}
                id={`weight-row-${entry.id}`}
                className="bg-neutral-950/40 border border-neutral-850 hover:border-neutral-750 p-4 rounded-2xl transition-all duration-300 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                {/* Weight & Delta Info (Primary Focal Area) */}
                <div className="flex items-center gap-4">
                  {/* Big Weight Figure */}
                  <div className="relative flex items-baseline gap-1 bg-neutral-950 border border-neutral-850 px-4 py-2.5 rounded-2xl shadow-inner min-w-[100px] justify-center">
                    <span className="text-xl font-extrabold text-white font-sans tracking-tight">
                      {entry.weight.toFixed(1)}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-neutral-550">kg</span>
                  </div>

                  {/* Progressive Delta Pill */}
                  <div className="flex flex-col text-left gap-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-neutral-200 font-bold font-mono">较上一次</span>
                    </div>
                    {hasChange ? (
                      <span
                        className={`inline-flex items-center gap-1 font-mono text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                          isGain
                            ? 'bg-rose-500/10 text-rose-450 border-rose-500/15'
                            : 'bg-emerald-500/10 text-emerald-450 border-emerald-500/15'
                        }`}
                      >
                        {isGain ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                        {isGain ? '+' : ''}{entry.delta.toFixed(1)} kg
                      </span>
                    ) : (
                      <span className="text-neutral-500 inline-flex items-center gap-1 font-mono text-[11px] px-2.5 py-0.5 rounded-full bg-neutral-900 border border-neutral-850/50">
                        <Minus size={11} strokeWidth={3} />
                        持平
                      </span>
                    )}
                  </div>
                </div>

                {/* Metadata & Assessment Details (Spacious and breathable) */}
                <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
                  {/* Date & User note */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-neutral-400">
                      <Calendar size={13} className="text-neutral-500 shrink-0" />
                      <span className="text-xs font-semibold font-mono">{entry.date}</span>
                    </div>
                    {entry.note ? (
                      <p className="text-[11px] text-neutral-300 bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-850 max-w-xs leading-relaxed italic">
                        "{entry.note}"
                      </p>
                    ) : (
                      <p className="text-[11px] text-neutral-600">无额外备注</p>
                    )}
                  </div>

                  {/* BMI Index and Delete actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t border-neutral-850/30 sm:border-t-0">
                    {/* Premium BMI Status Badge */}
                    <div className="flex flex-col items-end gap-1 text-right">
                      <span className="text-[10px] uppercase font-mono text-neutral-500 font-bold">BMI 指数</span>
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border shadow-sm ${bmiBadgeClass}`}>
                        {bmi.toFixed(1)} • {bmiText}
                      </span>
                    </div>

                    {/* Delete action button */}
                    <button
                      onClick={() => onDeleteWeight(entry.id)}
                      id={`btn-weight-del-${entry.id}`}
                      className="text-neutral-500 hover:text-rose-450 hover:bg-rose-500/10 p-2.5 rounded-xl border border-transparent hover:border-rose-500/20 transition-all duration-200 active:scale-90"
                      title="删除本次体重记录"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div id="weight-history-empty" className="bg-neutral-955 border border-neutral-850 rounded-2xl p-10 text-center text-neutral-500 text-xs">
          暂无历史体重记录。添加今早的体重，开始极简追踪 ⚖️
        </div>
      )}
    </div>
  );
}
