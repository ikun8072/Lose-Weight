import React, { useState, useMemo, useRef, useEffect } from 'react';
import { WeightEntry, UserProfile } from '../types';

interface StatsChartProps {
  entries: WeightEntry[];
  profile: UserProfile;
}

export default function StatsChart({ entries, profile }: StatsChartProps) {
  const [timeRange, setTimeRange] = useState<7 | 30 | 180>(30);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [hoveredX, setHoveredX] = useState<number>(0);
  const [hoveredY, setHoveredY] = useState<number>(0);
  
  // Sort entries chronologically to ensure the graph plots correctly
  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [entries]);

  // Filter based on selected time range
  const filteredEntries = useMemo(() => {
    const today = new Date();
    const cutoffDate = new Date();
    cutoffDate.setDate(today.getDate() - timeRange);
    
    return sortedEntries.filter(entry => new Date(entry.date) >= cutoffDate);
  }, [sortedEntries, timeRange]);

  // Calculations
  const stats = useMemo(() => {
    if (filteredEntries.length === 0) return { min: 0, max: 0, current: 0, change: 0, bmi: 0 };
    
    const weights = filteredEntries.map(e => e.weight);
    const min = Math.min(...weights);
    const max = Math.max(...weights);
    const current = sortedEntries[sortedEntries.length - 1]?.weight || 0;
    
    // Total change historically
    const firstWeight = sortedEntries[0]?.weight || current;
    const change = Math.round((current - firstWeight) * 10) / 10;
    
    // BMI calculation
    const heightInMeters = profile.height / 100;
    const bmi = heightInMeters > 0 ? Math.round((current / (heightInMeters * heightInMeters)) * 10) / 10 : 0;
    
    return { min, max, current, change, bmi };
  }, [filteredEntries, sortedEntries, profile.height]);

  // SVG Chart boundaries & calculations
  const width = 500;
  const height = 240;
  const paddingLeft = 40;
  const paddingRight = 16;
  const paddingTop = 20;
  const paddingBottom = 30;

  const chartBounds = useMemo(() => {
    if (filteredEntries.length === 0) return null;

    const weights = filteredEntries.map(e => e.weight);
    let minW = Math.min(...weights, profile.targetWeight) - 0.5;
    let maxW = Math.max(...weights, profile.targetWeight) + 0.5;
    
    // Safe guard equal weight crash
    if (minW === maxW) {
      minW -= 2;
      maxW += 2;
    }

    const mapX = (index: number) => {
      if (filteredEntries.length <= 1) return paddingLeft + (width - paddingLeft - paddingRight) / 2;
      return paddingLeft + (index / (filteredEntries.length - 1)) * (width - paddingLeft - paddingRight);
    };

    const mapY = (w: number) => {
      const scale = (height - paddingTop - paddingBottom);
      return height - paddingBottom - ((w - minW) / (maxW - minW)) * scale;
    };

    // Construct line SVG path
    let points = filteredEntries.map((entry, idx) => ({
      x: mapX(idx),
      y: mapY(entry.weight),
      weight: entry.weight,
      date: entry.date,
      note: entry.note
    }));

    let linePath = "";
    let areaPath = "";

    if (points.length > 0) {
      linePath = `M ${points[0].x} ${points[0].y} ` + points.slice(1).map(p => `L ${p.x} ${p.y}`).join(' ');
      
      // Close the area path for modern gradient rendering
      const bottomY = height - paddingBottom;
      areaPath = `${linePath} L ${points[points.length - 1].x} ${bottomY} L ${points[0].x} ${bottomY} Z`;
    }

    const targetLineY = mapY(profile.targetWeight);

    return { points, linePath, areaPath, targetLineY, minW, maxW, mapY };
  }, [filteredEntries, profile.targetWeight]);

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!chartBounds || chartBounds.points.length === 0) return;
    const svgRect = e.currentTarget.getBoundingClientRect();
    const cursorX = ((e.clientX - svgRect.left) / svgRect.width) * width;
    
    // Find closest point by X coordinate
    let closestIndex = 0;
    let minDiff = Infinity;
    
    chartBounds.points.forEach((p, idx) => {
      const diff = Math.abs(p.x - cursorX);
      if (diff < minDiff) {
        minDiff = diff;
        closestIndex = idx;
      }
    });

    const activePoint = chartBounds.points[closestIndex];
    setHoveredIndex(closestIndex);
    setHoveredX(activePoint.x);
    setHoveredY(activePoint.y);
  };

  const handleMouseLeave = () => {
    setHoveredIndex(null);
  };

  const latestWeight = stats.current;
  const bmiCategory = useMemo(() => {
    const bmi = stats.bmi;
    if (bmi < 18.5) return { text: '偏瘦 BMI', color: 'text-amber-400' };
    if (bmi < 24) return { text: '正常 BMI', color: 'text-emerald-400 font-medium' };
    if (bmi < 28) return { text: '微胖 BMI', color: 'text-amber-500' };
    return { text: '偏重 BMI', color: 'text-rose-500' };
  }, [stats.bmi]);

  return (
    <div id="stats-chart-card" className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      {/* Background radial accent */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/5 rounded-full blur-[64px] pointer-events-none" />
      
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-neutral-400 tracking-wider uppercase">体重趋势</span>
            <div className="h-1 w-1 rounded-full bg-emerald-400 md:animate-pulse" />
          </div>
          <div className="flex items-baseline gap-3 mt-1">
            <h1 className="text-4xl font-sans font-bold tracking-tight text-white">{latestWeight.toFixed(1)} <span className="text-lg font-normal text-neutral-400">kg</span></h1>
            <span className={`text-xs px-2 py-0.5 rounded-full ${stats.change <= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'} font-medium`}>
              {stats.change <= 0 ? '' : '+'}{stats.change} kg (全程)
            </span>
          </div>
        </div>
        
        {/* Time Tabs */}
        <div className="flex bg-neutral-950 p-1 rounded-lg border border-neutral-800 self-start sm:self-center">
          {([7, 30, 180] as const).map(range => (
            <button
              key={range}
              id={`tab-range-${range}`}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all duration-200 ${
                timeRange === range
                  ? 'bg-neutral-850 text-emerald-400 shadow-sm border border-neutral-800'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {range === 7 ? '近1周' : range === 30 ? '近1月' : '近半年'}
            </button>
          ))}
        </div>
      </div>

      {/* Mini Stats Grid */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-neutral-950/65 rounded-xl p-3 border border-neutral-800/40 text-center sm:text-left">
          <p className="text-[10px] uppercase font-mono text-neutral-500">最高体重</p>
          <p className="text-base font-semibold text-neutral-200 mt-0.5">{stats.max.toFixed(1)} <span className="text-xs font-normal text-neutral-400">kg</span></p>
        </div>
        <div className="bg-neutral-950/65 rounded-xl p-3 border border-neutral-800/40 text-center sm:text-left">
          <p className="text-[10px] uppercase font-mono text-neutral-500">最低体重</p>
          <p className="text-base font-semibold text-neutral-200 mt-0.5">{stats.min.toFixed(1)} <span className="text-xs font-normal text-neutral-400">kg</span></p>
        </div>
        <div className="bg-neutral-950/65 rounded-xl p-3 border border-neutral-800/40 text-center sm:text-left">
          <p className="text-[10px] uppercase font-mono text-neutral-500">{bmiCategory.text}</p>
          <p className={`text-base font-semibold mt-0.5 ${bmiCategory.color}`}>{stats.bmi.toFixed(1)}</p>
        </div>
      </div>

      {/* SVG Canvas Stage */}
      <div id="chart-stage" className="relative w-full h-[240px]">
        {chartBounds && chartBounds.points.length > 0 ? (
          <svg
            className="w-full h-full select-none"
            viewBox={`0 0 ${width} ${height}`}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
          >
            <defs>
              {/* Fade blue/emerald area gradient */}
              <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
              </linearGradient>
              
              {/* Line Stroke gradient */}
              <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#34d399" />
                <stop offset="100%" stopColor="#059669" />
              </linearGradient>
            </defs>

            {/* Subtle Grid Horizontal lines (ticks) */}
            {(() => {
              const ticks = 4;
              const gridLines = [];
              const diff = chartBounds.maxW - chartBounds.minW;
              for (let i = 0; i <= ticks; i++) {
                const w = chartBounds.minW + (diff * (i / ticks));
                const y = chartBounds.mapY(w);
                gridLines.push(
                  <g key={`grid-y-${i}`} className="opacity-20">
                    <line
                      x1={paddingLeft}
                      y1={y}
                      x2={width - paddingRight}
                      y2={y}
                      stroke="#404040"
                      strokeWidth="1"
                      strokeDasharray="4 4"
                    />
                    <text
                      x={paddingLeft - 8}
                      y={y + 3}
                      fill="#888888"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="end"
                    >
                      {w.toFixed(1)}
                    </text>
                  </g>
                );
              }
              return gridLines;
            })()}

            {/* Target Weight Line Indicator */}
            <g className="opacity-45">
              <line
                x1={paddingLeft}
                y1={chartBounds.targetLineY}
                x2={width - paddingRight}
                y2={chartBounds.targetLineY}
                stroke="#3b82f6"
                strokeWidth="1.5"
                strokeDasharray="6 3"
              />
              <text
                x={width - paddingRight - 4}
                y={chartBounds.targetLineY - 5}
                fill="#60a5fa"
                fontSize="8"
                fontFamily="monospace"
                fontWeight="bold"
                textAnchor="end"
              >
                目标: {profile.targetWeight.toFixed(1)} kg
              </text>
            </g>

            {/* Area under curve */}
            <path d={chartBounds.areaPath} fill="url(#areaGrad)" />

            {/* Main Weight trend path line */}
            <path
              d={chartBounds.linePath}
              fill="none"
              stroke="url(#lineGrad)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Hover Vertical Line Guide */}
            {hoveredIndex !== null && (
              <line
                x1={hoveredX}
                y1={paddingTop}
                x2={hoveredX}
                y2={height - paddingBottom}
                stroke="#10b981"
                strokeWidth="1"
                strokeDasharray="2 2"
                opacity="0.6"
              />
            )}

            {/* Interactive dot nodes */}
            {chartBounds.points.map((p, idx) => {
              const isHovered = hoveredIndex === idx;
              const isKeyPoint = p.note !== undefined || idx === 0 || idx === chartBounds.points.length - 1;
              const isToday = idx === chartBounds.points.length - 1;

              return (
                <g key={`point-${idx}`}>
                  {/* Subtle pulsing background for key milestones */}
                  {isToday && (
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r="8"
                      fill="#10b981"
                      opacity="0.2"
                      className="animate-ping"
                    />
                  )}
                  
                  {/* Inner Core node circle */}
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={isHovered ? "6" : isToday ? "4" : isKeyPoint ? "3.5" : "1.5"}
                    fill={isToday ? "#10b981" : isHovered ? "#34d399" : isKeyPoint ? "#a3a3a3" : "#525252"}
                    stroke={isHovered || isToday ? "#171717" : "none"}
                    strokeWidth={isHovered || isToday ? "2" : "0"}
                    className="transition-all duration-150"
                  />
                </g>
              );
            })}

            {/* X-Axis Ticks (Dates) */}
            {(() => {
              const pts = chartBounds.points;
              if (pts.length === 0) return null;
              
              // Select 3 smart tick indexes depending on dataset size
              const tickIndexes = [0, Math.floor(pts.length / 2), pts.length - 1];
              // Avoid duplicates if array is very small
              const uniqueIndexes = Array.from(new Set(tickIndexes));

              return uniqueIndexes.map(idx => {
                const p = pts[idx];
                if (!p) return null;
                const dateObj = new Date(p.date);
                const formatStr = `${dateObj.getMonth() + 1}/${dateObj.getDate()}`;
                
                return (
                  <text
                    key={`x-tick-${idx}`}
                    x={p.x}
                    y={height - 12}
                    fill="#737373"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor={idx === 0 ? "start" : idx === pts.length - 1 ? "end" : "middle"}
                  >
                    {formatStr}
                  </text>
                );
              });
            })()}
          </svg>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-neutral-500 text-xs">
            暂无趋势数据，点击 “记体重” 添加入手
          </div>
        )}

        {/* Hover Floating Card Tooltip */}
        {hoveredIndex !== null && chartBounds && chartBounds.points[hoveredIndex] && (
          <div
            id="tooltip-hovercard"
            className="absolute bg-neutral-950/95 border border-neutral-800 rounded-lg p-2.5 shadow-2xl pointer-events-none transition-all duration-75 text-left z-20 w-36"
            style={{
              left: `${Math.min(width - 150, Math.max(10, hoveredX - 70))}px`,
              top: `${Math.min(height - 110, Math.max(5, hoveredY - 80))}px`,
            }}
          >
            <p className="text-[10px] text-neutral-400 font-mono">
              {(() => {
                const dateObj = new Date(chartBounds.points[hoveredIndex].date);
                return `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2,'0')}-${String(dateObj.getDate()).padStart(2,'0')}`;
              })()}
            </p>
            <p className="text-sm font-bold text-emerald-400 mt-0.5">
              {chartBounds.points[hoveredIndex].weight.toFixed(1)} <span className="text-xs font-normal text-white">kg</span>
            </p>
            {chartBounds.points[hoveredIndex].note && (
              <p className="text-[9px] text-amber-400 leading-tight border-t border-neutral-800/80 pt-1 mt-1 truncate">
                {chartBounds.points[hoveredIndex].note}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
