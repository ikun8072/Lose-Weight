import React, { useState, useRef } from 'react';
import { MealType, MealEntry, UserProfile } from '../types';
import { Camera, Upload, Check, Trash2, Loader2, Sparkles } from 'lucide-react';

interface MealFormProps {
  onAddMeal: (
    type: MealType,
    image: string,
    note?: string,
    nutrition?: { calories: number; carbs: number; protein: number; fat: number; mealName: string }
  ) => void;
  profile: UserProfile;
}

export default function MealForm({ onAddMeal, profile }: MealFormProps) {
  const [mealType, setMealType] = useState<MealType>('breakfast');
  const [image, setImage] = useState<string | null>(null);
  const [note, setNote] = useState<string>('');
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStatus, setAnalysisStatus] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const mealTypes: { value: MealType; label: string; icon: string; bg: string; text: string }[] = [
    { value: 'breakfast', label: '早餐', icon: '🍳', bg: 'bg-amber-500/10 border-amber-500/30', text: 'text-amber-400' },
    { value: 'lunch', label: '午餐', icon: '🍲', bg: 'bg-sky-500/10 border-sky-500/30', text: 'text-sky-400' },
    { value: 'dinner', label: '晚餐', icon: '🥩', bg: 'bg-indigo-500/10 border-indigo-500/30', text: 'text-indigo-400' },
    { value: 'snack', label: '加餐', icon: '☕', bg: 'bg-teal-500/10 border-teal-500/30', text: 'text-teal-400' },
  ];

  const quickNotes = [
    '高蛋白低脂肪，干净饮食',
    '稍微有些油脂，但碳水分量足够',
    '放纵餐一顿，快乐拉满',
    '今天练习完补充优质碳水',
    '控制碳水的一餐，全天清爽'
  ];

  // Process selected file
  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('请确保上传的内容是图片格式');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      setImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image || isAnalyzing) return;
    
    setIsAnalyzing(true);
    setAnalysisStatus('🍳 正在识别美食材质...');
    
    try {
      // Small status transition
      setTimeout(() => setAnalysisStatus('🔥 正在估算热量及三大宏量营养分布...'), 1500);
      setTimeout(() => setAnalysisStatus('✍️ 正在整理运动饮食Coach建议...'), 3500);

      const apiBase = (profile.apiServerUrl || '').trim().replace(/\/+$/, '');
      const response = await fetch(`${apiBase}/api/analyze-meal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: image,
          mealType: mealType,
          profile: profile
        })
      });

      if (!response.ok) {
        throw new Error('Analysis request failed');
      }

      const result = await response.json();
      
      // We will attach advice to the user's note if returned or keep as meta
      const finalNote = note.trim()
        ? `${note.trim()} (AI 智能识别: ${result.mealName}。建议: ${result.briefCoachAdvice})`
        : `智能识别: ${result.mealName}。${result.briefCoachAdvice}`;

      onAddMeal(
        mealType,
        image,
        finalNote,
        {
          calories: result.calories,
          carbs: result.carbs,
          protein: result.protein,
          fat: result.fat,
          mealName: result.mealName
        }
      );

      // reset form states
      setImage(null);
      setNote('');
    } catch (err) {
      console.error(err);
      // Fallback
      onAddMeal(mealType, image, note.trim() || undefined);
      setImage(null);
      setNote('');
    } finally {
      setIsAnalyzing(false);
      setAnalysisStatus('');
    }
  };

  return (
    <div id="meal-uploader-form" className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 rounded-full blur-[48px] pointer-events-none" />
      
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">每日膳食</h2>
          <p className="text-xs text-neutral-400 mt-0.5">上传配餐照片，自动生成卡路里与宏量营养素分析</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Meal Type Selection Tabs */}
        <div className="grid grid-cols-4 gap-2">
          {mealTypes.map((type) => {
            const isSelected = mealType === type.value;
            return (
              <button
                key={type.value}
                type="button"
                id={`meal-type-tab-${type.value}`}
                onClick={() => setMealType(type.value)}
                className={`py-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all duration-200 active:scale-95 ${
                  isSelected
                    ? `${type.bg} ${type.text} border-2 ring-1 ring-offset-2 ring-offset-neutral-900 ring-sky-500/20`
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                <span className="text-xl leading-none">{type.icon}</span>
                <span className="text-[10px] font-medium">{type.label}</span>
              </button>
            );
          })}
        </div>

        {/* Drag Drop Image Uploader Frame */}
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={!image ? triggerFileInput : undefined}
          className={`relative border-2 border-dashed rounded-xl h-48 flex flex-col items-center justify-center transition-all cursor-pointer overflow-hidden ${
            image ? 'border-neutral-800 bg-neutral-950' : 'hover:bg-neutral-950/40'
          } ${dragActive ? 'border-sky-500 bg-sky-500/5' : 'border-neutral-800'}`}
        >
          <input
            ref={fileInputRef}
            type="file"
            id="meal-photo-input"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />

          {image ? (
            <div className="w-full h-full relative group">
              <img
                src={image}
                alt="Meal preview"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-neutral-950/60 opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center justify-center gap-2">
                <button
                  type="button"
                  id="btn-reselect-photo"
                  onClick={(e) => {
                    e.stopPropagation();
                    triggerFileInput();
                  }}
                  className="bg-neutral-800 hover:bg-neutral-700 text-white p-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-all"
                >
                  <Camera size={14} /> 重新拍摄
                </button>
                <button
                  type="button"
                  id="btn-delete-photo"
                  onClick={(e) => {
                    e.stopPropagation();
                    setImage(null);
                  }}
                  className="bg-rose-950 text-rose-400 border border-rose-800/40 hover:bg-rose-900 p-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-all"
                >
                  <Trash2 size={14} /> 移除
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 text-center p-4">
              <div className="w-12 h-12 rounded-full bg-neutral-950/80 border border-neutral-800 flex items-center justify-center text-neutral-400 group-hover:text-white transition-colors">
                <Camera size={20} className="text-neutral-400" />
              </div>
              <div>
                <p className="text-xs font-semibold text-neutral-200">点击拍照 或 拖拽照片至此</p>
                <p className="text-[10px] text-neutral-500 mt-1">支持 JPEG, PNG 等餐食随手拍格式</p>
              </div>
            </div>
          )}
        </div>

        {/* Quick templates + Note field */}
        <div className="space-y-2">
          <label htmlFor="meal-notes-text" className="text-[10px] uppercase font-mono text-neutral-500">饮食说明</label>
          <textarea
            id="meal-notes-text"
            rows={2}
            className="w-full bg-neutral-950 border border-neutral-850 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-sky-500 transition-all resize-none"
            placeholder="今天吃的什么好料？添加一句碎碎念..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          
          {/* Quick chip options */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {quickNotes.map((phrase, i) => (
              <button
                key={i}
                type="button"
                id={`quick-note-phrase-${i}`}
                onClick={() => setNote(phrase)}
                className="text-[10px] text-neutral-400 bg-neutral-950 hover:bg-neutral-850 hover:text-white border border-neutral-850 rounded-full px-2.5 py-1 transition-all"
              >
                {phrase}
              </button>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <button
          type="submit"
          id="btn-add-meal-submit"
          disabled={!image || isAnalyzing}
          className={`w-full font-semibold py-3 px-4 rounded-xl shadow-lg transition-all text-xs tracking-wider uppercase font-mono flex items-center justify-center gap-1.5 ${
            image && !isAnalyzing
              ? 'bg-sky-500 hover:bg-sky-400 text-neutral-950 shadow-sky-500/10 active:scale-[0.98]'
              : 'bg-neutral-800 text-neutral-500 cursor-not-allowed opacity-50'
          }`}
        >
          {isAnalyzing ? (
            <div className="flex items-center gap-2 text-white">
              <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
              <span className="text-[11px] normal-case tracking-normal">{analysisStatus}</span>
            </div>
          ) : (
            <>
              <Check size={14} /> AI 智能识别并上传日记
            </>
          )}
        </button>
      </form>
    </div>
  );
}
