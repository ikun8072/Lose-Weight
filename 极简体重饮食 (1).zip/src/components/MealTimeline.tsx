import React, { useState, useMemo } from 'react';
import { MealEntry, MealType, WeightEntry } from '../types';
import { Sparkles, Calendar, Clock, Trash2, Heart, Eye } from 'lucide-react';

interface MealTimelineProps {
  meals: MealEntry[];
  weights: WeightEntry[];
  onDeleteMeal: (id: string) => void;
}

export default function MealTimeline({ meals, weights, onDeleteMeal }: MealTimelineProps) {
  const [selectedType, setSelectedType] = useState<MealType | 'all'>('all');
  const [lightboxMeal, setLightboxMeal] = useState<MealEntry | null>(null);

  // Group meals and weights by date
  const sortedDates = useMemo(() => {
    // Collect all unique dates with meals
    const filteredMeals = selectedType === 'all'
      ? meals
      : meals.filter(m => m.type === selectedType);

    const mealDates = filteredMeals.map(m => m.date);
    const uniqueDates = Array.from(new Set(mealDates)).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    
    return uniqueDates.map(date => {
      const dayMeals = filteredMeals
        .filter(m => m.date === date)
        .sort((a,b) => b.time.localeCompare(a.time)); // latest time first
      
      const dayWeight = weights.find(w => w.date === date);

      return {
        date,
        meals: dayMeals,
        weight: dayWeight?.weight
      };
    }).filter(group => group.meals.length > 0);
  }, [meals, weights, selectedType]);

  const mealMetaMap: Record<MealType, { label: string; bg: string; text: string; icon: string }> = {
    breakfast: { label: '早餐', bg: 'bg-amber-500/10 border-amber-500/20', text: 'text-amber-400', icon: '🍳' },
    lunch: { label: '午餐', bg: 'bg-sky-500/10 border-sky-500/20', text: 'text-sky-400', icon: '🍲' },
    dinner: { label: '晚餐', bg: 'bg-indigo-500/10 border-indigo-500/20', text: 'text-indigo-400', icon: '🥩' },
    snack: { label: '加餐', bg: 'bg-teal-500/10 border-teal-500/20', text: 'text-teal-400', icon: '☕' },
  };

  const getLocalDateString = (dateStr: string) => {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    if (dateStr === today) return '今天 (Today)';
    if (dateStr === yesterday) return '昨天 (Yesterday)';
    
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[1]}月${parts[2]}日`;
    }
    return dateStr;
  };

  return (
    <div id="meals-timeline-card" className="space-y-6">
      {/* Filters bar */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            饮食影像轴
            <Sparkles size={16} className="text-sky-400" />
          </h2>
          <p className="text-xs text-neutral-400">流水账式的美食胶片，记录真实的能量起伏</p>
        </div>

        {/* Tag Filters */}
        <div className="flex bg-neutral-950 p-1 rounded-lg border border-neutral-800">
          <button
            onClick={() => setSelectedType('all')}
            id="filter-meal-type-all"
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all duration-200 ${
              selectedType === 'all'
                ? 'bg-neutral-850 text-sky-400 border border-neutral-800 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            全部
          </button>
          {(Object.keys(mealMetaMap) as MealType[]).map(type => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              id={`filter-meal-type-${type}`}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all duration-200 ${
                selectedType === type
                  ? 'bg-neutral-850 text-sky-400 border border-neutral-800 shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {mealMetaMap[type].label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Waterfall timeline list */}
      {sortedDates.length > 0 ? (
        <div className="space-y-8 relative before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-[1.5px] before:bg-neutral-800">
          {sortedDates.map((group) => (
            <div key={group.date} id={`day-timeline-group-${group.date}`} className="space-y-4 relative pl-8 sm:pl-10">
              
              {/* Timeline marker node dot */}
              <div className="absolute left-1.5 sm:left-2.5 top-1.5 w-3.5 h-3.5 rounded-full border-2 border-neutral-800 bg-neutral-950 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-sky-400" />
              </div>

              {/* Day Header */}
              <div className="flex items-center justify-between border-b border-neutral-800/40 pb-2">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-neutral-200 tracking-tight">{getLocalDateString(group.date)}</h3>
                  <span className="text-[10px] font-mono text-neutral-550">{group.date}</span>
                </div>
                {group.weight && (
                  <span className="text-xs font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 px-2 py-0.5 rounded-full">
                    ⚖️ 体重: {group.weight} kg
                  </span>
                )}
              </div>

              {/* Day's Food Matrix (Grid layout) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {group.meals.map((meal) => {
                  const meta = mealMetaMap[meal.type];
                  return (
                    <div
                      key={meal.id}
                      id={`meal-card-${meal.id}`}
                      className="group bg-neutral-900 border border-neutral-800/60 hover:border-neutral-700 rounded-xl overflow-hidden shadow transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between"
                    >
                      {/* Interactive Image Frame */}
                      <div
                        className="relative h-44 overflow-hidden cursor-pointer"
                        onClick={() => setLightboxMeal(meal)}
                        id={`meal-img-frame-${meal.id}`}
                      >
                        <img
                          src={meal.image}
                          alt={meal.note || 'Meal'}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        {/* Hover Overlay triggers */}
                        <div className="absolute inset-0 bg-neutral-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center justify-center">
                          <span className="bg-neutral-900/90 text-white text-xs px-3 py-1.5 rounded-lg border border-neutral-700 flex items-center gap-1.5 font-medium">
                            <Eye size={12} /> 查看大图
                          </span>
                        </div>

                        {/* Top-Right Tag Stamp */}
                        <span className={`absolute top-2.5 right-2.5 text-[10px] font-bold px-2 py-0.5 rounded-full border ${meta.bg} ${meta.text}`}>
                          {meta.icon} {meta.label}
                        </span>

                        {/* Meal timestamp stamp footer */}
                        <span className="absolute bottom-2 left-2 text-[10px] bg-neutral-950/80 text-neutral-300 px-2 py-0.5 rounded-md font-mono flex items-center gap-1">
                          <Clock size={10} /> {meal.time}
                        </span>
                      </div>

                      {/* Comment Box */}
                      <div className="p-3 text-left space-y-2">
                        {meal.calories !== undefined && (
                          <div className="flex flex-wrap gap-1.5 items-center mb-1">
                            <span className="text-[10px] bg-sky-500/10 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded-md font-bold">
                              🔥 {meal.calories} kcal
                            </span>
                            <span className="text-[9px] bg-neutral-950 text-neutral-400 border border-neutral-850 px-1.5 py-0.5 rounded font-mono">
                              蛋 {meal.protein}g / 碳 {meal.carbs}g / 脂 {meal.fat}g
                            </span>
                          </div>
                        )}
                        <p className="text-xs text-neutral-300 font-normal line-clamp-2 leading-relaxed">
                          {meal.note || <span className="text-neutral-500 italic">“无备注，干饭专心”</span>}
                        </p>
                        
                        {/* Action details footer inside card */}
                        <div className="flex items-center justify-between border-t border-neutral-855/30 mt-3 pt-2 text-[11px] text-neutral-500">
                          <div className="flex items-center gap-1">
                            <Heart size={10} className="text-neutral-600 hover:text-rose-500 cursor-pointer" />
                            <span>美味值 100%</span>
                          </div>
                          
                          <button
                            onClick={() => onDeleteMeal(meal.id)}
                            id={`btn-meal-del-${meal.id}`}
                            className="text-neutral-600 hover:text-rose-400 p-0.5 rounded transition-all"
                            title="删除这一餐"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          ))}
        </div>
      ) : (
        <div id="timeline-empty-stage" className="bg-neutral-950 border border-neutral-850 rounded-xl p-8 text-center flex flex-col items-center justify-center">
          <p className="text-neutral-400 text-sm">此分类下暂无影像日记</p>
          <p className="text-neutral-600 text-xs mt-1">今天也请好好吃饭，拍个美食吧 📸</p>
        </div>
      )}

      {/* Lightbox Modal projection */}
      {lightboxMeal && (
        <div
          id="lightbox-popup"
          className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 transition-all"
          onClick={() => setLightboxMeal(null)}
        >
          {/* Close trigger anywhere or simple centered frame */}
          <div
            className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Action Header bar inside popup */}
            <div className="absolute top-2.5 left-2.5 z-10 flex gap-2">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shadow ${mealMetaMap[lightboxMeal.type].bg} ${mealMetaMap[lightboxMeal.type].text}`}>
                {mealMetaMap[lightboxMeal.type].icon} {mealMetaMap[lightboxMeal.type].label}
              </span>
              <span className="text-[10px] bg-neutral-950/80 text-neutral-300 border border-neutral-850 px-2.5 py-0.5 rounded-md font-mono">
                {lightboxMeal.date} at {lightboxMeal.time}
              </span>
            </div>

            <button
              onClick={() => setLightboxMeal(null)}
              className="absolute top-2.5 right-2.5 bg-neutral-950/80 text-neutral-400 hover:text-white w-6 h-6 rounded-full flex items-center justify-center font-bold text-sm border border-neutral-800 z-10"
            >
              ×
            </button>

            {/* Immersive lightbox picture */}
            <div className="h-80 sm:h-96 w-full overflow-hidden relative bg-black flex items-center">
              <img
                src={lightboxMeal.image}
                alt="Meal popup details"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Detail footer in lightbox popup */}
            <div className="p-4 text-left border-t border-neutral-800/80 space-y-3">
              <p className="text-xs text-neutral-400 font-mono flex items-center gap-1.5">
                <Calendar size={12} />
                记载于 {getLocalDateString(lightboxMeal.date)} ({lightboxMeal.date}) {lightboxMeal.time}
              </p>
              
              {lightboxMeal.calories !== undefined && (
                <div className="grid grid-cols-4 gap-2 bg-neutral-950 p-3 rounded-xl border border-neutral-850/50 text-center">
                  <div>
                    <div className="text-[10px] text-neutral-500 font-medium">卡路里</div>
                    <div className="text-xs font-bold text-sky-400 mt-0.5">{lightboxMeal.calories} kcal</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-500 font-medium">蛋白质</div>
                    <div className="text-xs font-bold text-emerald-400 mt-0.5">{lightboxMeal.protein} g</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-500 font-medium">碳水</div>
                    <div className="text-xs font-bold text-amber-400 mt-0.5">{lightboxMeal.carbs} g</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-500 font-medium">脂肪</div>
                    <div className="text-xs font-bold text-rose-450 mt-0.5">{lightboxMeal.fat} g</div>
                  </div>
                </div>
              )}

              <h4 className="text-sm text-neutral-100 font-medium leading-relaxed bg-neutral-950 p-3 rounded-xl border border-neutral-850/50">
                {lightboxMeal.note || <span className="text-neutral-500 italic">“无备注，干饭专心”</span>}
              </h4>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
