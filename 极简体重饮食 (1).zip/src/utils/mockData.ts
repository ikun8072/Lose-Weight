import { WeightEntry, MealEntry, UserProfile } from '../types';

export const defaultProfile: UserProfile = {
  name: "Kyler",
  age: 22,
  height: 178, // cm
  targetWeight: 70.0, // kg
  activityLevel: "moderate"
};

// Generates simulated weight data for the last 30 days
const generateWeightData = (): WeightEntry[] => {
  const data: WeightEntry[] = [];
  const startWeight = 77.8;
  const targetWeight = 73.2;
  const today = new Date();
  
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    const dateString = date.toISOString().split('T')[0];
    
    // Create a realistic weight decay with minor daily fluctuations
    const progress = (29 - i) / 29;
    const baseWeight = startWeight - (startWeight - targetWeight) * progress;
    // Fluctuation of +/- 0.3 kg
    const fluctuation = Math.sin(i * 1.5) * 0.25 + Math.cos(i * 0.7) * 0.15;
    const weight = Math.round((baseWeight + fluctuation) * 10) / 10;
    
    data.push({
      id: `w-${i}`,
      date: dateString,
      weight,
      note: i === 29 ? "初始记录" : i === 0 ? "今早空腹体重" : undefined
    });
  }
  return data;
};

// Selection of high-quality food photography from Unsplash to give an incredible aesthetic look immediately
export const defaultMeals: MealEntry[] = [
  {
    id: `m-1`,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '08:30',
    type: 'breakfast',
    image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=600',
    note: '牛油果水煮蛋全麦多士 ＋ 黑咖啡，完美开启搬砖日',
    calories: 360,
    carbs: 24,
    protein: 16,
    fat: 22
  },
  {
    id: `m-2`,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '12:15',
    type: 'lunch',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=600',
    note: '鸡胸肉藜麦时蔬沙拉，今天油脂控制得不错',
    calories: 450,
    carbs: 42,
    protein: 38,
    fat: 14
  },
  {
    id: `m-3`,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '19:40',
    type: 'dinner',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
    note: '海盐煎三文鱼排 + 蒸西兰花，优质脂肪拉满',
    calories: 520,
    carbs: 12,
    protein: 44,
    fat: 32
  },
  {
    id: `m-4`,
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '08:15',
    type: 'breakfast',
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=600',
    note: '希腊酸奶蓝莓碗 + 燕麦碎，抗氧化满分',
    calories: 310,
    carbs: 38,
    protein: 18,
    fat: 8
  },
  {
    id: `m-5`,
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '13:00',
    type: 'lunch',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=600',
    note: '经典减脂轻食碗，豆腐配鹰嘴豆',
    calories: 410,
    carbs: 55,
    protein: 21,
    fat: 12
  },
  {
    id: `m-6`,
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '18:45',
    type: 'dinner',
    image: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&q=80&w=600',
    note: '经典慢煨慢煮菲力牛肉，优质红肉蛋白',
    calories: 580,
    carbs: 22,
    protein: 52,
    fat: 28
  },
  {
    id: `m-7`,
    date: new Date().toISOString().split('T')[0],
    time: '09:00',
    type: 'breakfast',
    image: 'https://images.unsplash.com/photo-1506084868230-bb9d95c24759?auto=format&fit=crop&q=80&w=600',
    note: '燕麦片配香蕉草莓切片 ＋ 一勺纯乳清蛋白粉',
    calories: 390,
    carbs: 56,
    protein: 28,
    fat: 6
  },
  {
    id: `m-8`,
    date: new Date().toISOString().split('T')[0],
    time: '12:30',
    type: 'lunch',
    image: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600',
    note: '慢烤鸡腿卷配糙米饭，膳食纤维和碳水比例很舒服',
    calories: 480,
    carbs: 54,
    protein: 36,
    fat: 15
  }
];

export const defaultWeights = generateWeightData();
